/**
 * Animação do barco que segue o mouse/toque (adaptada do arquivo da MUSA).
 *
 * - WaveGrid: grade que simula ondas na água (cada toque vira uma ondulação).
 * - BoatController: controla o barco: segue o dedo/mouse, mergulha no botão,
 *   navega por cima dele e volta a seguir. Deixa uma esteira de espuma.
 */

export interface BoatOptions {
  section: HTMLElement
  waterCanvas: HTMLCanvasElement
  boat: HTMLElement
  boatInner: HTMLElement
  button: HTMLElement
  buttonCanvas: HTMLCanvasElement
  onFirstMove?: () => void
}

/** Tamanho do barco na tela (largura x comprimento, em pixels). */
export const BOAT_WIDTH = 44
export const BOAT_LENGTH = 106

const SEA_CELL = 7 // tamanho de cada "quadradinho" da água do fundo (esteira do barco)
const BUTTON_CELL = 3 // idem, para a água dentro do botão
const MAX_SPEED = 520
const FOLLOW_GAIN = 5
const DIVE_SCALE = 0.32
const DIVE_TIME = 0.7
const EXIT_TIME = 0.5

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value))
const lerp = (from: number, to: number, amount: number) => from + (to - from) * amount
const rand = (min: number, max: number) => min + Math.random() * (max - min)
const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3)
const smoothstep = (t: number) => t * t * (3 - 2 * t)
/** Número "aleatório" sempre igual para o mesmo n (entre 0 e 1). */
const hash = (n: number): number => {
  const v = Math.sin(n * 127.1 + 311.7) * 43758.5453
  return v - Math.floor(v)
}

/** Pontinhos de espuma desenhados uma vez só e reaproveitados (mais leve e mais macio que círculos). */
function makeFoamSprite(seed: number): HTMLCanvasElement {
  const size = 64
  const canvas = document.createElement('canvas')
  canvas.width = size
  canvas.height = size
  const g = get2d(canvas)
  for (let i = 0; i < 7; i++) {
    const cx = size / 2 + (hash(seed * 9 + i) - 0.5) * 22
    const cy = size / 2 + (hash(seed * 13 + i) - 0.5) * 22
    const r = 9 + hash(seed * 17 + i) * 12
    const grad = g.createRadialGradient(cx, cy, 0, cx, cy, r)
    grad.addColorStop(0, 'rgba(255,255,255,0.55)')
    grad.addColorStop(0.55, 'rgba(255,255,255,0.22)')
    grad.addColorStop(1, 'rgba(255,255,255,0)')
    g.fillStyle = grad
    g.fillRect(0, 0, size, size)
  }
  for (let i = 0; i < 16; i++) {
    const angle = hash(seed * 21 + i) * Math.PI * 2
    const dist = hash(seed * 25 + i) * 20
    const r = 0.9 + hash(seed * 29 + i) * 2
    g.fillStyle = 'rgba(255,255,255,0.8)'
    g.beginPath()
    g.arc(size / 2 + Math.cos(angle) * dist, size / 2 + Math.sin(angle) * dist, r, 0, Math.PI * 2)
    g.fill()
  }
  return canvas
}

/** Menor diferença entre dois ângulos (em radianos). */
function angleDiff(from: number, to: number): number {
  let diff = (to - from) % (Math.PI * 2)
  if (diff > Math.PI) diff -= Math.PI * 2
  if (diff < -Math.PI) diff += Math.PI * 2
  return diff
}

function get2d(canvas: HTMLCanvasElement): CanvasRenderingContext2D {
  const ctx = canvas.getContext('2d')
  if (!ctx) throw new Error('Canvas 2D indisponível neste navegador.')
  return ctx
}

export class WaveGrid {
  w = 0
  h = 0
  cur = new Float32Array(0)
  prev = new Float32Array(0)
  damping: number

  constructor(width: number, height: number, damping = 0.985) {
    this.damping = damping
    this.resize(width, height)
  }

  resize(width: number, height: number): void {
    this.w = Math.max(3, Math.floor(width))
    this.h = Math.max(3, Math.floor(height))
    const size = this.w * this.h
    this.cur = new Float32Array(size)
    this.prev = new Float32Array(size)
  }

  clear(): void {
    this.cur.fill(0)
    this.prev.fill(0)
  }

  /** Cria uma ondulação em (x, y). */
  disturb(x: number, y: number, amount: number, radius = 1): void {
    const reach = Math.ceil(radius * 2)
    const cx = Math.round(x)
    const cy = Math.round(y)
    for (let dy = -reach; dy <= reach; dy++) {
      for (let dx = -reach; dx <= reach; dx++) {
        const px = cx + dx
        const py = cy + dy
        if (px < 1 || py < 1 || px >= this.w - 1 || py >= this.h - 1) continue
        const dist = Math.hypot(dx, dy) / radius
        this.cur[py * this.w + px] += amount * Math.exp(-dist * dist)
      }
    }
  }

  /** Avança a simulação um passo. */
  step(): void {
    const { w, h, cur, prev, damping } = this
    for (let row = 1; row < h - 1; row++) {
      let i = row * w + 1
      for (let col = 1; col < w - 1; col++) {
        prev[i] = ((cur[i - 1] + cur[i + 1] + cur[i - w] + cur[i + w]) * 0.5 - prev[i]) * damping
        i++
      }
    }
    this.prev = cur
    this.cur = prev
  }
}

interface Foam {
  x: number
  y: number
  vx: number
  vy: number
  r: number
  grow: number
  age: number
  life: number
  a: number
}

interface Rect {
  x: number
  y: number
  w: number
  h: number
}


/* ------------------------------------------------------------------ */
/* Espuma e oceano                                                      */
/* ------------------------------------------------------------------ */

/**
 * Desenha o mar do fundo: água translúcida com manchas de luz e pequenas ondas
 * que sobem de baixo para cima, formando espuma na crista. Tudo curvo e orgânico.
 */
class OceanRenderer {
  private foam: HTMLCanvasElement[]
  private points = new Float32Array(0)

  constructor(foam: HTMLCanvasElement[]) {
    this.foam = foam
  }

  draw(ctx: CanvasRenderingContext2D, W: number, H: number, t: number): void {
    this.drawLight(ctx, W, H, t)
    this.drawWaves(ctx, W, H, t)
  }

  /** Manchas macias de luz que passeiam pela água (como a luz atravessando o mar). */
  private drawLight(ctx: CanvasRenderingContext2D, W: number, H: number, t: number): void {
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    const base = Math.max(240, Math.min(W, H) * 0.42)
    for (let i = 0; i < 6; i++) {
      const cx = W * (0.5 + 0.48 * Math.sin(t * 0.06 * (1 + i * 0.13) + i * 2.1))
      const cy = H * (0.5 + 0.48 * Math.cos(t * 0.045 * (1 + i * 0.17) + i * 1.3))
      const radius = base * (0.8 + (i % 3) * 0.3)
      const glow = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius)
      glow.addColorStop(0, 'rgba(120,230,235,0.11)')
      glow.addColorStop(0.5, 'rgba(90,205,225,0.05)')
      glow.addColorStop(1, 'rgba(90,205,225,0)')
      ctx.fillStyle = glow
      ctx.fillRect(cx - radius, cy - radius, radius * 2, radius * 2)
    }
    ctx.restore()
  }

  private drawWaves(ctx: CanvasRenderingContext2D, W: number, H: number, t: number): void {
    const spacing = 58
    const speed = 17 // pixels por segundo, subindo
    const margin = 60
    const step = 12
    const maxCount = Math.ceil(W / step) + 4
    if (this.points.length < maxCount * 3) this.points = new Float32Array(maxCount * 3)
    const pts = this.points // x, y, envelope (força da onda naquele ponto)
    const travelled = t * speed
    const kFirst = Math.ceil((travelled - (H + margin * 2)) / spacing)
    const kLast = Math.floor(travelled / spacing)

    ctx.save()
    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'
    for (let k = kFirst; k <= kLast; k++) {
      // Cada "linha" de mar tem 2 ondulações curtas, em lugares e alturas diferentes
      for (let piece = 0; piece < 2; piece++) {
        const id = k * 2 + piece
        const h1 = hash(id)
        const h2 = hash(id + 0.5)
        const h3 = hash(id * 1.7 + 3)
        const h4 = hash(id * 2.3 + 7)
        const y = H + margin - (travelled - k * spacing) + (hash(id * 3.1) - 0.5) * 44
        const depth = Math.min(1, Math.max(0, y / H))
        const topFade = Math.min(1, Math.max(0, (y + 20) / 140))
        const a = (0.5 + 0.5 * depth) * topFade
        if (a < 0.02) continue

        const len = W * (0.3 + 0.5 * h4)
        const x0 = (hash(id * 5.9) * 1.3 - 0.15) * W + t * (h2 - 0.5) * 14
        const from = Math.max(-step, x0)
        const to = Math.min(W + step, x0 + len)
        if (to <= from) continue
        const count = Math.min(maxCount, Math.ceil((to - from) / step) + 1)

        const amp = (7 + 9 * h1) * (0.6 + 0.4 * depth)
        const slope = (h3 - 0.5) * 0.14
        const k1 = (Math.PI * 2) / (240 + 190 * h3)
        const k2 = (Math.PI * 2) / (95 + 85 * h1)
        const s1 = t * (0.5 + h2 * 0.4) + h1 * 6.28
        const s2 = t * (0.7 + h3 * 0.4) + h2 * 6.28
        const mid = x0 + len / 2

        for (let i = 0; i < count; i++) {
          const x = from + ((to - from) * i) / (count - 1)
          const along = Math.min(1, Math.max(0, (x - x0) / len))
          const env = Math.pow(Math.sin(Math.PI * along), 0.8)
          pts[i * 3] = x
          pts[i * 3 + 1] = y + slope * (x - mid) + amp * Math.sin(x * k1 + s1) + amp * 0.55 * Math.sin(x * k2 - s2)
          pts[i * 3 + 2] = env
        }
        const crestAt = (x: number) => {
          const along = (x - from) / (to - from || 1)
          const i = Math.min(count - 1, Math.max(0, Math.round(along * (count - 1))))
          return pts[i * 3 + 1]
        }

        // 1) a "face" iluminada da onda, logo atrás da crista (abaixo dela), afinando nas pontas
        const faceH = 30 + 14 * h1
        const face = ctx.createLinearGradient(0, y - amp, 0, y + faceH + amp)
        face.addColorStop(0, `rgba(255,255,255,${(0.2 * a).toFixed(3)})`)
        face.addColorStop(1, 'rgba(255,255,255,0)')
        ctx.fillStyle = face
        ctx.beginPath()
        ctx.moveTo(pts[0], pts[1])
        for (let i = 1; i < count; i++) ctx.lineTo(pts[i * 3], pts[i * 3 + 1])
        for (let i = count - 1; i >= 0; i--) ctx.lineTo(pts[i * 3], pts[i * 3 + 1] + faceH * pts[i * 3 + 2])
        ctx.closePath()
        ctx.fill()

        // 2) sombra suave na água logo à frente da crista (acima dela)
        const trough = ctx.createLinearGradient(0, y - amp - 28, 0, y + amp)
        trough.addColorStop(0, 'rgba(2,40,70,0)')
        trough.addColorStop(1, `rgba(2,40,70,${(0.2 * a).toFixed(3)})`)
        ctx.fillStyle = trough
        ctx.beginPath()
        ctx.moveTo(pts[0], pts[1])
        for (let i = 1; i < count; i++) ctx.lineTo(pts[i * 3], pts[i * 3 + 1] - 28 * pts[i * 3 + 2])
        for (let i = count - 1; i >= 0; i--) ctx.lineTo(pts[i * 3], pts[i * 3 + 1])
        ctx.closePath()
        ctx.fill()

        // 3) espuma na crista: brilho largo + fios quebrados + faíscas (some nas pontas)
        const fade = ctx.createLinearGradient(x0, 0, x0 + len, 0)
        fade.addColorStop(0, 'rgba(255,255,255,0)')
        fade.addColorStop(0.18, 'rgba(255,255,255,1)')
        fade.addColorStop(0.82, 'rgba(255,255,255,1)')
        fade.addColorStop(1, 'rgba(255,255,255,0)')
        ctx.strokeStyle = fade
        ctx.beginPath()
        ctx.moveTo(pts[0], pts[1])
        for (let i = 1; i < count; i++) ctx.lineTo(pts[i * 3], pts[i * 3 + 1])
        ctx.setLineDash([])
        ctx.globalAlpha = 0.1 * a
        ctx.lineWidth = 9
        ctx.stroke()
        ctx.setLineDash([26 + 40 * h1, 7 + 12 * h2, 10 + 16 * h3, 9])
        ctx.lineDashOffset = -t * 22 * (h2 - 0.35)
        ctx.globalAlpha = 0.42 * a
        ctx.lineWidth = 3
        ctx.stroke()
        ctx.setLineDash([4 + 7 * h3, 14 + 20 * h1])
        ctx.lineDashOffset = t * 14 * (h1 - 0.4)
        ctx.globalAlpha = 0.7 * a
        ctx.lineWidth = 1.4
        ctx.stroke()
        ctx.setLineDash([])
        ctx.globalAlpha = 1

        // 4) bolhas e manchas de espuma que andam junto com a onda
        for (let j = 0; j < 12; j++) {
          const bx = from + (to - from) * (0.08 + 0.84 * hash(id * 13 + j))
          const along = Math.min(1, Math.max(0, (bx - x0) / len))
          const env = Math.sin(Math.PI * along)
          const by = crestAt(bx) + (hash(id * 7 + j) - 0.35) * 14
          if (j < 3) {
            const size = 32 + 30 * hash(id * 3 + j)
            ctx.globalAlpha = Math.min(1, 0.6 * a * env)
            ctx.drawImage(this.foam[Math.abs(id + j) % 3], bx - size / 2, by - size / 2, size, size)
            ctx.globalAlpha = 1
          } else {
            const radius = 0.8 + 2.4 * hash(id * 5 + j + 9)
            ctx.fillStyle = `rgba(255,255,255,${((0.25 + 0.4 * hash(id + j * 1.3)) * a * env).toFixed(3)})`
            ctx.beginPath()
            ctx.arc(bx, by, radius, 0, Math.PI * 2)
            ctx.fill()
          }
        }
      }
    }
    ctx.restore()
  }
}

type Phase = 'follow' | 'dive' | 'sail' | 'exit'

export class BoatController {
  private o: BoatOptions
  private ctx: CanvasRenderingContext2D
  private bctx: CanvasRenderingContext2D
  private dpr = 1
  private W = 0
  private H = 0

  private sim = new WaveGrid(4, 4, 0.978)
  private simCanvas = document.createElement('canvas')
  private simCtx: CanvasRenderingContext2D
  private simImg!: ImageData

  private bsim = new WaveGrid(4, 4, 0.99)
  private bsimCanvas = document.createElement('canvas')
  private bsimCtx: CanvasRenderingContext2D
  private bsimImg!: ImageData

  private foam: Foam[] = []
  private bfoam: Foam[] = []
  private foamSprites: HTMLCanvasElement[] = [makeFoamSprite(1), makeFoamSprite(2), makeFoamSprite(3)]
  private ocean = new OceanRenderer(this.foamSprites)

  private phase: Phase = 'follow'
  private phaseT = 0
  private t = 0
  private last = 0
  private raf = 0
  private running = false

  private x = 0
  private y = 0
  private vx = 0
  private vy = 0
  private ang = 0
  private scale = 1
  private lift = 0
  private lastStern: { x: number; y: number } | null = null

  private pointer = { cx: 0, cy: 0, active: false, seen: false }
  private seaOn = false
  private seaUntil = 0
  private btn: Rect = { x: 0, y: 0, w: 0, h: 0 }
  private drop = { x: 0, y: 0 }
  private dir = { x: 1, y: 0 }
  private dist = 0
  private sailTime = 2
  private diveFrom = { x: 0, y: 0, ang: 0 }
  private resolveSequence: (() => void) | null = null
  private ro: ResizeObserver

  constructor(options: BoatOptions) {
    this.o = options
    this.ctx = get2d(options.waterCanvas)
    this.bctx = get2d(options.buttonCanvas)
    this.simCtx = get2d(this.simCanvas)
    this.bsimCtx = get2d(this.bsimCanvas)
    this.resize()
    this.ro = new ResizeObserver(() => this.resize())
    this.ro.observe(options.section)
    const rect = this.getButtonRect()
    this.x = rect.x + rect.w / 2 - Math.min(170, this.W / 2 - 40)
    this.y = rect.y + rect.h / 2
    this.ang = 0
  }

  private resize = (): void => {
    const { section, waterCanvas } = this.o
    this.W = section.clientWidth
    this.H = section.clientHeight
    this.dpr = Math.min(window.devicePixelRatio || 1, 2)
    waterCanvas.width = Math.max(1, Math.round(this.W * this.dpr))
    waterCanvas.height = Math.max(1, Math.round(this.H * this.dpr))
    const cols = Math.ceil(this.W / SEA_CELL) + 1
    const rows = Math.ceil(this.H / SEA_CELL) + 1
    this.sim.resize(cols, rows)
    this.simCanvas.width = this.sim.w
    this.simCanvas.height = this.sim.h
    this.simImg = this.simCtx.createImageData(this.sim.w, this.sim.h)
  }

  private onPointer = (event: PointerEvent): void => {
    this.pointer.cx = event.clientX
    this.pointer.cy = event.clientY
    this.pointer.active = true
    if (!this.pointer.seen) {
      this.pointer.seen = true
      this.o.onFirstMove?.()
    }
  }

  private onLeave = (event: PointerEvent): void => {
    if (event.pointerType === 'mouse') this.pointer.active = false
  }

  private frame = (now: number): void => {
    if (!this.running) return
    if (!this.last) this.last = now
    const dt = Math.min(0.05, (now - this.last) / 1000)
    this.last = now
    this.t += dt
    this.phaseT += dt

    switch (this.phase) {
      case 'follow':
        this.updateFollow(dt)
        break
      case 'dive':
        this.updateDive()
        break
      case 'sail':
        this.updateSail(dt)
        break
      case 'exit':
        this.updateExit(dt)
        break
    }

    this.sim.step()
    this.drawSea(dt)
    if (this.seaOn || now < this.seaUntil) {
      this.bsim.step()
      this.bsim.step()
      this.drawButtonSea(dt)
    }
    this.applyBoat()
    this.raf = requestAnimationFrame(this.frame)
  }

  start(): void {
    if (this.running) return
    this.running = true
    const section = this.o.section
    section.addEventListener('pointermove', this.onPointer)
    section.addEventListener('pointerdown', this.onPointer)
    section.addEventListener('pointerleave', this.onLeave)
    this.last = 0
    this.raf = requestAnimationFrame(this.frame)
  }

  stop(): void {
    this.running = false
    cancelAnimationFrame(this.raf)
    const section = this.o.section
    section.removeEventListener('pointermove', this.onPointer)
    section.removeEventListener('pointerdown', this.onPointer)
    section.removeEventListener('pointerleave', this.onLeave)
    this.ro.disconnect()
  }

  /** Toca a sequência: o barco mergulha no botão, navega e sai. Resolve quando termina. */
  playBooking(): Promise<void> {
    return new Promise<void>((resolve) => {
      if (this.phase !== 'follow') {
        resolve()
        return
      }
      this.resolveSequence = resolve
      const rect = this.getButtonRect()
      this.btn = rect
      this.setupButtonSea(rect)
      this.drop = {
        x: clamp(this.x - rect.x, rect.w * 0.22, rect.w * 0.78),
        y: clamp(this.y - rect.y, rect.h * 0.34, rect.h * 0.66),
      }
      const dx = this.x - (rect.x + rect.w / 2)
      const dy = this.y - (rect.y + rect.h / 2)
      let ex: number
      let ey: number
      if (Math.hypot(dx, dy) < 10) {
        ex = Math.cos(this.ang)
        ey = Math.sin(this.ang)
      } else {
        const side = dx !== 0 ? Math.sign(dx) : Math.cos(this.ang) >= 0 ? 1 : -1
        ex = side * Math.max(Math.abs(dx), Math.abs(dy) * 0.6, 6)
        ey = dy * 0.45
      }
      const len = Math.hypot(ex, ey) || 1
      this.dir = { x: ex / len, y: ey / len }
      this.dist = this.distanceToEdge(rect)
      this.sailTime = clamp(this.dist / 55, 1.6, 2.8)
      this.diveFrom = { x: this.x, y: this.y, ang: this.ang }
      this.phase = 'dive'
      this.phaseT = 0
      this.seaOn = true
      this.o.button.dataset.sea = 'on'
    })
  }

  /** Devolve o botão ao normal depois da animação. */
  resetButton(): void {
    this.o.button.dataset.sea = 'off'
    this.seaUntil = performance.now() + 700
    this.seaOn = false
  }

  private setupButtonSea(rect: Rect): void {
    const cols = Math.ceil(rect.w / BUTTON_CELL)
    const rows = Math.ceil(rect.h / BUTTON_CELL)
    this.bsim.resize(cols, rows)
    this.bsimCanvas.width = this.bsim.w
    this.bsimCanvas.height = this.bsim.h
    this.bsimImg = this.bsimCtx.createImageData(this.bsim.w, this.bsim.h)
    const canvas = this.o.buttonCanvas
    canvas.width = Math.max(1, Math.round(rect.w * this.dpr))
    canvas.height = Math.max(1, Math.round(rect.h * this.dpr))
    this.bfoam = []
  }

  private getButtonRect(): Rect {
    const section = this.o.section.getBoundingClientRect()
    const button = this.o.button.getBoundingClientRect()
    return { x: button.left - section.left, y: button.top - section.top, w: button.width, h: button.height }
  }

  /** Quantos pixels o barco consegue andar dentro do botão (formato de pílula). */
  private distanceToEdge(rect: Rect): number {
    const radius = rect.h / 2 - 11
    const inside = (px: number, py: number) => {
      const cx = clamp(px, rect.h / 2, rect.w - rect.h / 2)
      return Math.hypot(px - cx, py - rect.h / 2) <= radius
    }
    let n = 0
    while (n < 600 && inside(this.drop.x + this.dir.x * (n + 1), this.drop.y + this.dir.y * (n + 1))) n += 1
    return Math.max(n, 40)
  }

  private updateFollow(dt: number): void {
    const section = this.o.section.getBoundingClientRect()
    let targetX: number
    let targetY: number
    if (this.pointer.active) {
      targetX = clamp(this.pointer.cx - section.left, 0, this.W)
      targetY = clamp(this.pointer.cy - section.top, 0, this.H)
    } else {
      // Sem mouse/toque: o barco passeia em volta do botão
      const rect = this.getButtonRect()
      const radiusX = Math.min(180, this.W / 2 - 50)
      const radiusY = 90
      targetX = rect.x + rect.w / 2 + Math.cos(this.t * 0.5) * radiusX
      targetY = rect.y + rect.h / 2 + Math.sin(this.t * 0.5) * radiusY
    }
    let ax = (targetX - this.x) * FOLLOW_GAIN
    let ay = (targetY - this.y) * FOLLOW_GAIN
    const mag = Math.hypot(ax, ay)
    if (mag > MAX_SPEED) {
      ax = (ax / mag) * MAX_SPEED
      ay = (ay / mag) * MAX_SPEED
    }
    const smooth = 1 - Math.exp(-dt * 5)
    this.vx += (ax - this.vx) * smooth
    this.vy += (ay - this.vy) * smooth
    this.x += this.vx * dt
    this.y += this.vy * dt
    const speed = Math.hypot(this.vx, this.vy)
    if (speed > 14) {
      const heading = Math.atan2(this.vy, this.vx)
      this.ang += angleDiff(this.ang, heading) * (1 - Math.exp(-dt * 7))
    }
    this.scale = 1 + Math.sin(this.t * 2.4) * 0.012
    this.lift = 0
    this.wakeOnWater(dt, speed)
  }

  private updateDive(): void {
    const l = clamp(this.phaseT / DIVE_TIME, 0, 1)
    const eased = easeOutCubic(l)
    const targetX = this.btn.x + this.drop.x
    const targetY = this.btn.y + this.drop.y
    this.x = lerp(this.diveFrom.x, targetX, eased)
    this.y = lerp(this.diveFrom.y, targetY, eased)
    const heading = Math.atan2(this.dir.y, this.dir.x)
    this.ang = this.diveFrom.ang + angleDiff(this.diveFrom.ang, heading) * smoothstep(l)
    this.scale = lerp(1, DIVE_SCALE, smoothstep(l)) + 0.5 * Math.sin(Math.PI * l)
    this.lift = 40 * Math.sin(Math.PI * l)
    this.vx = 0
    this.vy = 0
    this.lastStern = null
    if (l >= 1) {
      this.splash()
      this.phase = 'sail'
      this.phaseT = 0
    }
  }

  private splash(): void {
    this.bsim.disturb(this.drop.x / BUTTON_CELL, this.drop.y / BUTTON_CELL, 2.2, 2.2)
    for (let i = 0; i < 22; i++) {
      const angle = (i / 22) * Math.PI * 2 + rand(-0.15, 0.15)
      const speed = rand(35, 95)
      this.bfoam.push({
        x: this.drop.x,
        y: this.drop.y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed * 0.7,
        r: rand(1.4, 3),
        grow: rand(2, 6),
        age: 0,
        life: rand(0.5, 0.95),
        a: 0.9,
      })
    }
    const wx = this.btn.x + this.drop.x
    const wy = this.btn.y + this.drop.y
    this.sim.disturb(wx / SEA_CELL, wy / SEA_CELL, -1.1, 2.4)
  }

  private updateSail(_dt: number): void {
    const p = clamp(this.phaseT / this.sailTime, 0, 1)
    const eased = 1 - Math.cos((p * Math.PI) / 2)
    const u = this.drop.x + this.dir.x * this.dist * eased
    const n = this.drop.y + this.dir.y * this.dist * eased
    this.x = this.btn.x + u
    this.y = this.btn.y + n
    this.ang = Math.atan2(this.dir.y, this.dir.x)
    this.scale = DIVE_SCALE
    this.lift = 0
    const speed = ((this.dist * Math.PI) / 2 / this.sailTime) * Math.sin((p * Math.PI) / 2)
    this.vx = this.dir.x * speed
    this.vy = this.dir.y * speed

    const back = BOAT_LENGTH * 0.5 * DIVE_SCALE * 0.85
    const sx = u - this.dir.x * back
    const sy = n - this.dir.y * back
    const px = -this.dir.y
    const py = this.dir.x
    const strength = clamp(speed / 60, 0.15, 1.2)
    this.bsim.disturb(sx / BUTTON_CELL, sy / BUTTON_CELL, -0.4 * strength, 1.2)
    for (let i = 0; i < 2; i++) {
      const side = rand(-1, 1)
      this.bfoam.push({
        x: sx + px * side * 3,
        y: sy + py * side * 3,
        vx: px * side * rand(6, 22),
        vy: py * side * rand(6, 22),
        r: rand(1.4, 2.8),
        grow: rand(3, 7),
        age: 0,
        life: rand(0.7, 1.3),
        a: 0.85,
      })
    }
    if (this.bfoam.length > 400) this.bfoam.splice(0, this.bfoam.length - 400)

    if (p >= 1) {
      this.phase = 'exit'
      this.phaseT = 0
      this.lastStern = null
      const done = this.resolveSequence
      this.resolveSequence = null
      done?.()
    }
  }

  private updateExit(dt: number): void {
    const p = clamp(this.phaseT / EXIT_TIME, 0, 1)
    this.x += this.vx * dt
    this.y += this.vy * dt
    this.scale = lerp(DIVE_SCALE, 1, easeOutCubic(p))
    this.lift = 0
    if (p > 0.6) this.wakeOnWater(dt, Math.hypot(this.vx, this.vy))
    if (p >= 1) {
      this.phase = 'follow'
      this.phaseT = 0
    }
  }

  /** Esteira de espuma atrás do barco. */
  private wakeOnWater(dt: number, speed: number): void {
    const cos = Math.cos(this.ang)
    const sin = Math.sin(this.ang)
    const back = BOAT_LENGTH * 0.5 * this.scale * 0.92
    const sternX = this.x - cos * back
    const sternY = this.y - sin * back
    if (speed > 22) {
      const px = -sin
      const py = cos
      const from = this.lastStern ?? { x: sternX, y: sternY }
      const steps = clamp(Math.round((speed * dt) / 5), 1, 4)
      for (let d = 1; d <= steps; d++) {
        const k = d / steps
        const fx = lerp(from.x, sternX, k)
        const fy = lerp(from.y, sternY, k)
        const jitter = rand(-1, 1)
        this.foam.push({
          x: fx + px * jitter * 4,
          y: fy + py * jitter * 4,
          vx: px * jitter * rand(4, 14),
          vy: py * jitter * rand(4, 14),
          r: rand(3, 6),
          grow: rand(4, 9),
          age: 0,
          life: rand(1, 1.7),
          a: 0.55,
        })
        const side = Math.random() < 0.5 ? -1 : 1
        this.foam.push({
          x: fx + px * side * 8,
          y: fy + py * side * 8,
          vx: px * side * rand(18, 38),
          vy: py * side * rand(18, 38),
          r: rand(2, 4),
          grow: rand(3, 7),
          age: 0,
          life: rand(1.2, 2),
          a: 0.4,
        })
      }
      this.sim.disturb(sternX / SEA_CELL, sternY / SEA_CELL, -clamp(speed / 700, 0.05, 0.3), 1.1)
      if (this.foam.length > 700) this.foam.splice(0, this.foam.length - 700)
    }
    this.lastStern = { x: sternX, y: sternY }
  }

  private stepFoam(list: Foam[], dt: number): void {
    for (let i = list.length - 1; i >= 0; i--) {
      const f = list[i]
      f.age += dt
      if (f.age >= f.life) {
        list.splice(i, 1)
        continue
      }
      f.x += f.vx * dt
      f.y += f.vy * dt
      f.vx *= 0.985
      f.vy *= 0.985
      f.r += f.grow * dt
    }
  }

  private drawFoam(ctx: CanvasRenderingContext2D, list: Foam[]): void {
    for (const f of list) {
      const alpha = f.a * Math.pow(1 - f.age / f.life, 1.4)
      const size = f.r * 3
      ctx.globalAlpha = Math.min(1, alpha * 1.25)
      ctx.drawImage(this.foamSprites[Math.floor(f.life * 997) % 3], f.x - size, f.y - size, size * 2, size * 2)
    }
    ctx.globalAlpha = 1
  }

  private drawSea(dt: number): void {
    const { w, h, cur } = this.sim
    const data = this.simImg.data
    for (let row = 0; row < h; row++) {
      for (let col = 0; col < w; col++) {
        const i = row * w + col
        const p = i * 4
        if (col === 0 || row === 0 || col === w - 1 || row === h - 1) {
          data[p + 3] = 0
          continue
        }
        const slope = (cur[i - 1] - cur[i + 1] + cur[i - w] - cur[i + w]) * 1.3
        if (slope > 0) {
          data[p] = 255
          data[p + 1] = 255
          data[p + 2] = 255
          data[p + 3] = Math.min(110, slope * 255 * 0.55)
        } else {
          data[p] = 3
          data[p + 1] = 38
          data[p + 2] = 66
          data[p + 3] = Math.min(70, -slope * 255 * 0.4)
        }
      }
    }
    this.simCtx.putImageData(this.simImg, 0, 0)
    const ctx = this.ctx
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0)
    ctx.clearRect(0, 0, this.W, this.H)
    this.ocean.draw(ctx, this.W, this.H, this.t)
    ctx.imageSmoothingEnabled = true
    ctx.drawImage(this.simCanvas, 0, 0, w, h, 0, 0, w * SEA_CELL, h * SEA_CELL)
    this.stepFoam(this.foam, dt)
    this.drawFoam(ctx, this.foam)
  }

  private drawButtonSea(dt: number): void {
    const { w, h, cur } = this.bsim
    const data = this.bsimImg.data
    for (let row = 0; row < h; row++) {
      const depth = h > 1 ? row / (h - 1) : 0
      const baseR = lerp(34, 9, depth)
      const baseG = lerp(190, 104, depth)
      const baseB = lerp(208, 132, depth)
      for (let col = 0; col < w; col++) {
        const i = row * w + col
        let shade = Math.sin(col * 0.4 + row * 0.25 + this.t * 2.2) * 0.07
        let foamAmount = 0
        if (col > 0 && row > 0 && col < w - 1 && row < h - 1) {
          shade += (cur[i - 1] - cur[i + 1] + cur[i - w] - cur[i + w]) * 1.6
          foamAmount = Math.max(0, Math.abs(cur[i]) - 1.1) * 0.5
        }
        shade = clamp(shade, -1, 1)
        let r = baseR + shade * 60
        let g = baseG + shade * 60
        let b = baseB + shade * 50
        if (foamAmount > 0) {
          const m = Math.min(1, foamAmount)
          r += (255 - r) * m
          g += (255 - g) * m
          b += (255 - b) * m
        }
        const p = i * 4
        data[p] = r
        data[p + 1] = g
        data[p + 2] = b
        data[p + 3] = 255
      }
    }
    this.bsimCtx.putImageData(this.bsimImg, 0, 0)
    const ctx = this.bctx
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0)
    ctx.clearRect(0, 0, this.btn.w, this.btn.h)
    ctx.imageSmoothingEnabled = true
    ctx.drawImage(this.bsimCanvas, 0, 0, w, h, 0, 0, w * BUTTON_CELL, h * BUTTON_CELL)
    this.stepFoam(this.bfoam, dt)
    this.drawFoam(ctx, this.bfoam)
    const sheen = ctx.createLinearGradient(0, 0, 0, this.btn.h)
    sheen.addColorStop(0, 'rgba(255,255,255,0.28)')
    sheen.addColorStop(0.45, 'rgba(255,255,255,0)')
    ctx.fillStyle = sheen
    ctx.fillRect(0, 0, this.btn.w, this.btn.h)
  }

  private applyBoat(): void {
    const { boat, boatInner } = this.o
    boat.style.transform = `translate3d(${this.x.toFixed(2)}px, ${this.y.toFixed(2)}px, 0)`
    const lift = this.lift
    const shadowAlpha = 0.4 - 0.12 * Math.min(1, lift / 40)
    boat.style.filter = `drop-shadow(0 ${(2 + lift * 0.3).toFixed(1)}px ${(3 + lift * 0.35).toFixed(1)}px rgba(0,25,45,${shadowAlpha.toFixed(2)}))`
    boatInner.style.transform = `rotate(${(this.ang + Math.PI / 2).toFixed(4)}rad) scale(${this.scale.toFixed(3)})`
  }
}
