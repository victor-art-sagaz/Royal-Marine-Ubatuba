interface WaveDividerProps {
  /** Classes de posição e COR (ex.: "absolute inset-x-0 bottom-0 text-white") */
  className?: string
}

const WAVE_PATH =
  'M0,60 C150,100 350,0 600,60 C850,120 1050,20 1200,60 C1350,100 1550,0 1800,60 C2050,120 2250,20 2400,60 L2400,120 L0,120 Z'

/** Onda animada que "navega" devagar. A cor vem do text-* (usa currentColor). */
export default function WaveDivider({ className = '' }: WaveDividerProps) {
  return (
    <div className={`pointer-events-none h-10 overflow-hidden sm:h-14 ${className}`} aria-hidden="true">
      <svg
        viewBox="0 0 2400 120"
        preserveAspectRatio="none"
        className="absolute bottom-0 h-full w-[200%] animate-wave-drift-slow opacity-40"
        fill="currentColor"
      >
        <path d={WAVE_PATH} />
      </svg>
      <svg
        viewBox="0 0 2400 120"
        preserveAspectRatio="none"
        className="absolute bottom-0 h-[80%] w-[200%] animate-wave-drift"
        fill="currentColor"
      >
        <path d={WAVE_PATH} />
      </svg>
    </div>
  )
}
