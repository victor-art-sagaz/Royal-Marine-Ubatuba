/**
 * Poucas tartarugas e baleias nadando bem devagar ao fundo (vistas de cima).
 * São só enfeite: ficam atrás do conteúdo e somem para quem prefere menos movimento.
 */

interface SwimmerSpec {
  kind: 'whale' | 'turtle'
  /** Posição vertical em % da área */
  top: number
  /** Altura do bicho, em pixels */
  size: number
  dir: 'right' | 'left'
  /** Segundos para atravessar a tela (quanto maior, mais devagar) */
  duration: number
  /** Atraso negativo = já começa no meio do caminho */
  delay: number
  opacity: number
}

const swimmers: SwimmerSpec[] = [
  { kind: 'whale', top: 6, size: 230, dir: 'right', duration: 130, delay: -38, opacity: 0.3 },
  { kind: 'whale', top: 60, size: 130, dir: 'left', duration: 170, delay: -95, opacity: 0.22 },
  { kind: 'turtle', top: 36, size: 70, dir: 'right', duration: 80, delay: -12, opacity: 0.42 },
  { kind: 'turtle', top: 80, size: 56, dir: 'left', duration: 95, delay: -50, opacity: 0.36 },
  { kind: 'turtle', top: 22, size: 48, dir: 'right', duration: 110, delay: -70, opacity: 0.32 },
]

function Turtle() {
  return (
    <svg viewBox="0 0 100 120" className="h-full w-full overflow-visible" aria-hidden="true">
      {/* Nadadeiras de trás */}
      <path d="M36 86 C26 92 20 101 24 104 C31 100 39 93 42 86 Z" fill="#7fdcc4" />
      <path d="M64 86 C74 92 80 101 76 104 C69 100 61 93 58 86 Z" fill="#7fdcc4" />
      {/* Nadadeiras da frente (batem devagar) */}
      <path
        d="M34 50 C14 44 2 32 6 24 C16 28 32 38 40 48 Z"
        fill="#8fe6cf"
        style={{ transformOrigin: '38px 49px', animation: 'flipper-a 3.4s ease-in-out infinite alternate' }}
      />
      <path
        d="M66 50 C86 44 98 32 94 24 C84 28 68 38 60 48 Z"
        fill="#8fe6cf"
        style={{ transformOrigin: '62px 49px', animation: 'flipper-b 3.4s ease-in-out infinite alternate' }}
      />
      {/* Rabinho */}
      <path d="M50 92 L45 106 L55 106 Z" fill="#7fdcc4" />
      {/* Cabeça */}
      <ellipse cx="50" cy="24" rx="9" ry="11" fill="#8fe6cf" />
      {/* Casco */}
      <ellipse cx="50" cy="62" rx="25" ry="31" fill="#2f8f7a" />
      <ellipse cx="50" cy="62" rx="20" ry="26" fill="#3fae96" />
      <g fill="none" stroke="#2f8f7a" strokeWidth="1.6" strokeLinejoin="round">
        <path d="M50 38 L62 46 L62 62 L50 70 L38 62 L38 46 Z" />
        <path d="M50 70 L50 90" />
        <path d="M38 62 L31 72" />
        <path d="M62 62 L69 72" />
        <path d="M38 46 L32 40" />
        <path d="M62 46 L68 40" />
      </g>
    </svg>
  )
}

function Whale() {
  return (
    <svg viewBox="0 0 120 320" className="h-full w-full overflow-visible" aria-hidden="true">
      {/* Nadadeiras peitorais compridas (marca da baleia-jubarte) */}
      <path
        d="M38 92 C22 112 8 150 4 186 C14 178 28 150 44 124 Z"
        fill="#bfe3ee"
        style={{ transformOrigin: '42px 100px', animation: 'flipper-a 5s ease-in-out infinite alternate' }}
      />
      <path
        d="M82 92 C98 112 112 150 116 186 C106 178 92 150 76 124 Z"
        fill="#bfe3ee"
        style={{ transformOrigin: '78px 100px', animation: 'flipper-b 5s ease-in-out infinite alternate' }}
      />
      {/* Cauda (bate devagar) */}
      <g style={{ transformOrigin: '60px 252px', animation: 'fluke 4.2s ease-in-out infinite alternate' }}>
        <path d="M60 248 C48 262 26 268 6 260 C22 282 44 286 60 276 C76 286 98 282 114 260 C94 268 72 262 60 248 Z" fill="#1d4466" />
        <path d="M60 262 L60 276" stroke="#0e2b46" strokeWidth="1.5" strokeLinecap="round" />
      </g>
      {/* Corpo */}
      <path
        d="M60 4 C74 4 82 20 84 40 C89 72 93 112 87 162 C83 202 73 236 66 256 L54 256 C47 236 37 202 33 162 C27 112 31 72 36 40 C38 20 46 4 60 4 Z"
        fill="#1d4466"
      />
      <path d="M60 22 L60 244" stroke="#0e2b46" strokeWidth="2" strokeLinecap="round" opacity="0.5" />
      <path d="M44 150 C48 190 54 220 60 240 C66 220 72 190 76 150" fill="none" stroke="#2c6089" strokeWidth="2" opacity="0.6" />
    </svg>
  )
}

export default function SeaCreatures() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden motion-reduce:hidden" aria-hidden="true">
      {swimmers.map((s, index) => {
        const width = s.kind === 'whale' ? (s.size * 120) / 320 : (s.size * 100) / 120
        return (
          <div
            key={index}
            className="swimmer"
            style={{
              top: `${s.top}%`,
              width,
              height: s.size,
              opacity: s.opacity,
              animation: `${s.dir === 'right' ? 'swim-right' : 'swim-left'} ${s.duration}s linear ${s.delay}s infinite`,
            }}
          >
            <div className="h-full w-full" style={{ animation: `swim-sway ${9 + index * 1.7}s ease-in-out infinite` }}>
              <div className="h-full w-full" style={{ transform: `rotate(${s.dir === 'right' ? 90 : -90}deg)` }}>
                {s.kind === 'whale' ? <Whale /> : <Turtle />}
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
